
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'utils/file_utils.dart';
import 'as9102_info_page.dart';
import 'as9102_viewer.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String buttonLabel = 'PURCHASE AS9102';

  @override
  void initState() {
    super.initState();
    _checkFileAndUpdateLabel();
  }

  Future<void> _checkFileAndUpdateLabel() async {
    bool exists = await checkAS9102FileExists();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('as9102Available', exists);
    setState(() {
      buttonLabel = exists ? 'AS9102' : 'PURCHASE AS9102';
    });
  }

  void _onAS9102Pressed() async {
    final prefs = await SharedPreferences.getInstance();
    bool exists = await checkAS9102FileExists();

    if (exists) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => AS9102ViewerPage()),
      );
    } else {
      await prefs.setBool('as9102Available', false);
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => AS9102InfoPage(onFileCheckComplete: _checkFileAndUpdateLabel)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("FAI Assistant")),
      body: Center(
        child: ElevatedButton(
          onPressed: _onAS9102Pressed,
          child: Text(buttonLabel),
        ),
      ),
    );
  }
}
